// LY/SECURITY server — بدون أي مكتبات خارجية، فقط Node.js 18+
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000, DBF=path.join(__dirname,'data.json');
const ADMIN_EMAIL=process.env.ADMIN_EMAIL||'hatemst9@gmail.com';
const ADMIN_PASS=process.env.ADMIN_PASSWORD||'LY@Admin#2026';
let db={users:[],requests:[],notifications:[],sessions:{}};
if(fs.existsSync(DBF))db=JSON.parse(fs.readFileSync(DBF,'utf8'));
const save=()=>fs.writeFileSync(DBF,JSON.stringify(db,null,1));
const uid=()=>crypto.randomBytes(8).toString('hex');
const hash=(p,s=crypto.randomBytes(16).toString('hex'))=>s+':'+crypto.scryptSync(p,s,64).toString('hex');
const verify=(p,h)=>{const[s,x]=h.split(':');return crypto.timingSafeEqual(Buffer.from(hash(p,s).split(':')[1],'hex'),Buffer.from(x,'hex'))};
if(!db.users.some(u=>u.role==='admin')){db.users.push({id:uid(),name:'المدير',email:ADMIN_EMAIL.toLowerCase(),pass:hash(ADMIN_PASS),role:'admin',created:Date.now()});save()}
const notify=(userId,text)=>db.notifications.push({id:uid(),userId,text,read:false,created:Date.now()});
const tries={};
const SERVICES=['تطوير مواقع','تطبيقات موبايل','اختبار اختراق','فحص الثغرات','حماية واستعادة حسابات','استشارات أمنية','أخرى'];
const pub=u=>({id:u.id,name:u.name,email:u.email,role:u.role});
const mime={'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png'};
http.createServer((req,res)=>{
  const send=(c,o)=>{res.writeHead(c,{'Content-Type':'application/json;charset=utf-8'});res.end(JSON.stringify(o))};
  const url=new URL(req.url,'http://x');
  if(!url.pathname.startsWith('/api/')){
    let f=path.join(__dirname,'public',url.pathname==='/'?'index.html':path.normalize(url.pathname));
    if(!f.startsWith(path.join(__dirname,'public'))||!fs.existsSync(f)||fs.statSync(f).isDirectory())f=path.join(__dirname,'public','index.html');
    res.writeHead(200,{'Content-Type':mime[path.extname(f)]||'application/octet-stream'});return fs.createReadStream(f).pipe(res);
  }
  let raw='';req.on('data',c=>{raw+=c;if(raw.length>1e5)req.destroy()});
  req.on('end',()=>{
    let b={};try{b=raw?JSON.parse(raw):{}}catch{return send(400,{error:'بيانات غير صالحة'})}
    const r=url.pathname.slice(5).split('/'),m=req.method;
    const tok=(req.headers.authorization||'').slice(7),me=db.users.find(u=>u.id===db.sessions[tok]);
    const s=x=>String(x||'').trim();
    try{
      if(r[0]==='register'&&m==='POST'){
        const name=s(b.name).slice(0,60),email=s(b.email).toLowerCase(),pass=String(b.password||'');
        if(name.length<2||!/^\S+@\S+\.\S+$/.test(email)||pass.length<6)return send(400,{error:'تأكد من الاسم والإيميل وكلمة سر لا تقل عن 6 أحرف'});
        if(db.users.some(u=>u.email===email))return send(409,{error:'الإيميل مسجل من قبل'});
        const u={id:uid(),name,email,pass:hash(pass),role:'user',created:Date.now()};db.users.push(u);
        db.users.filter(a=>a.role==='admin').forEach(a=>notify(a.id,`مستخدم جديد: ${name}`));
        const t=uid()+uid();db.sessions[t]=u.id;save();return send(200,{token:t,user:pub(u)});
      }
      if(r[0]==='login'&&m==='POST'){
        const ip=req.socket.remoteAddress;tries[ip]=(tries[ip]||[]).filter(t=>Date.now()-t<6e5);
        if(tries[ip].length>=10)return send(429,{error:'محاولات كثيرة، حاول بعد 10 دقائق'});
        const u=db.users.find(x=>x.email===s(b.email).toLowerCase());
        if(!u||!verify(String(b.password||''),u.pass)){tries[ip].push(Date.now());return send(401,{error:'الإيميل أو كلمة السر غير صحيحة'})}
        const t=uid()+uid();db.sessions[t]=u.id;save();return send(200,{token:t,user:pub(u)});
      }
      if(!me)return send(401,{error:'سجّل دخولك أولاً'});
      if(r[0]==='me')return send(200,{user:pub(me)});
      if(r[0]==='logout'){delete db.sessions[tok];save();return send(200,{ok:1})}
      if(r[0]==='requests'&&!r[1]&&m==='GET'){
        const l=(me.role==='admin'?db.requests:db.requests.filter(q=>q.userId===me.id)).sort((a,b)=>b.created-a.created);return send(200,{requests:l});
      }
      if(r[0]==='requests'&&!r[1]&&m==='POST'){
        const service=s(b.service),details=s(b.details).slice(0,2000);
        if(!SERVICES.includes(service)||details.length<10)return send(400,{error:'اختر الخدمة واكتب تفاصيل لا تقل عن 10 أحرف'});
        const q={id:uid(),userId:me.id,userName:me.name,userEmail:me.email,service,details,status:'pending',reply:'',created:Date.now()};
        db.requests.push(q);db.users.filter(a=>a.role==='admin').forEach(a=>notify(a.id,`طلب جديد (${service}) من ${me.name}`));save();return send(200,{request:q});
      }
      if(r[0]==='requests'&&r[1]&&m==='PATCH'){
        if(me.role!=='admin')return send(403,{error:'للمدير فقط'});
        const q=db.requests.find(x=>x.id===r[1]);if(!q)return send(404,{error:'الطلب غير موجود'});
        if(['pending','completed'].includes(b.status))q.status=b.status;
        if(typeof b.reply==='string')q.reply=b.reply.slice(0,2000);
        q.updated=Date.now();notify(q.userId,q.status==='completed'?`تم إكمال طلبك (${q.service})`:`تحديث على طلبك (${q.service})`);save();return send(200,{request:q});
      }
      if(r[0]==='notifications'&&m==='GET')return send(200,{notifications:db.notifications.filter(n=>n.userId===me.id).sort((a,b)=>b.created-a.created).slice(0,50)});
      if(r[0]==='notifications'&&m==='POST'){db.notifications.filter(n=>n.userId===me.id).forEach(n=>n.read=true);save();return send(200,{ok:1})}
      if(r[0]==='users'&&me.role==='admin')return send(200,{users:db.users.map(pub)});
      send(404,{error:'غير موجود'});
    }catch(e){console.error(e);send(500,{error:'خطأ في السيرفر'})}
  });
}).listen(PORT,()=>console.log(`LY/SECURITY يعمل على http://localhost:${PORT}\nحساب الأدمن: ${ADMIN_EMAIL}`));
