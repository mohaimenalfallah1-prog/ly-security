LY/SECURITY — تشغيل الموقع
1) ثبّت Node.js (نسخة 18 أو أحدث) من nodejs.org
2) افتح الطرفية داخل المجلد ثم شغّل:  node server.js
3) افتح المتصفح على  http://localhost:3000

حساب الأدمن:
  الإيميل:  hatemst9@gmail.com
  كلمة السر: LY@Admin#2026   (غيّرها: ADMIN_PASSWORD=كلمتك node server.js — قبل أول تشغيل)
البيانات تُحفظ في ملف data.json داخل المجلد.
للنشر على الإنترنت: ارفع المجلد على VPS أو Render/Railway وشغّل node server.js
